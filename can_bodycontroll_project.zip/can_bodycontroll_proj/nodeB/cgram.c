#include<lpc21xx.h>
#include"header.h"

void lcd_cgram(void)
{
int i;
unsigned char a[8]={0x2,0x4,0x8,0x1f,0x8,0x4,0x2,0x0};
lcd_cmd(0x40);
for(i=0;i<8;i++)
lcd_data(a[i]);

unsigned char b[8]={0x0,0x0,0x0,0x1e,0x0,0x0,0x0,0x0};
lcd_cmd(0x48);
for(i=0;i<8;i++)
lcd_data(b[i]);

unsigned char c[8]={0x8,0x4,0x2,0x1f,0x2,0x4,0x8,0x0};
lcd_cmd(0x50);
for(i=0;i<8;i++)
lcd_data(c[i]);

unsigned char d[8]={0x0,0x0,0x0,0xf,0x0,0x0,0x0,0x0};
lcd_cmd(0x58);
for(i=0;i<8;i++)
lcd_data(d[i]);
}






/*#include<lpc21xx.h>
#include"header.h"
#define sw1 ((IOPIN0>>0)&1)
#define sw2 ((IOPIN0>>1)&1)
#define sw3 ((IOPIN0>>2)&1)
int main()
{
	unsigned int f1=0,f2=0,f3=0;
	lcd_init();
	lcd_cgram();
  while(1)
	{
		if(f1==1)
		{
			while(1)
			{
				lcd_cmd(0x80);
				lcd_data(0);
				lcd_data(1);
				delay_ms(200);
				lcd_cmd(0x80);
				lcd_data(' ');
				lcd_data(' ');
				delay_ms(200);
				if(sw1==0||sw2==0||sw3==0)
					break;
			}
		}
		
		if(f3==1)
		{
			while(1)
			{
				lcd_cmd(0x8e);
				lcd_data(3);
				lcd_data(2);
				delay_ms(200);
				lcd_cmd(0x8e);
				lcd_data(' ');
				lcd_data(' ');
				delay_ms(200);
				if(sw1==0||sw2==0||sw3==0)
					break;
			}
		}
		
		
		if(sw1==0)
		{
			while(sw1==0);
			f1^=1;
			f3=0;
		}
		
		if(sw2==0)
		{
			while(sw2==0);
			f2^=1;
			if(f2==1)
			{
				lcd_cmd(0x87);
				lcd_data('*');
			}
			else
			{
				lcd_cmd(0x87);
				lcd_data(' ');
			}
		}
		
		if(sw3==0)
		{
			while(sw3==0);
			f3^=1;
			f1=0;
			if(f3==0)
			{
				lcd_cmd(0x8e);
				lcd_data(' ');
				lcd_data(' ');
			}
		}
	}
	
}*/


















