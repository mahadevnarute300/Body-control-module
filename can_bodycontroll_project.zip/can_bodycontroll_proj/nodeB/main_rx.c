#include <LPC21xx.H>
#include "header.h"
#define Hled (1<<17)
#define Rled (1<<18)
#define Lled (1<<19)

can r1;
u32 flag=0,Rf=0,Lf=0;

int main()
{
can_init();
config_vic_for_can();

IODIR0|=Hled|Rled|Lled;
IOSET0=Hled|Rled|Lled;

while(1)
{


if(Rf==1)
{
while(1)
{
IOCLR0=Rled;
delay_ms(500);
IOSET0=Rled;
delay_ms(500);
if(flag==1)
break;
}
}


if(Lf==1)
{
while(1)
{
IOCLR0=Lled;
delay_ms(500);
IOSET0=Lled;
delay_ms(500);
if(flag==1)
break;
}
}


if(flag==1)
{
flag=0;
if(r1.rtr==0)
{
switch(r1.byteA&0xff)
{
case 0x10: IOCLR0=Hled;
break;
case 0x11: IOSET0=Hled;
break;
case 0x12: 
Rf=1;
Lf=0;
break;
case 0x13: 
Rf=0;
break;
case 0x14: 
Rf=0;
Lf=1;
break;
case 0x15: 
Lf=0;
break;
}
}

}
}
}
