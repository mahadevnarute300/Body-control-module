typedef unsigned int u32;
typedef unsigned char u8;

typedef struct can_msg
{
u8 id;
u8 rtr;
u32 dlc;
u32 byteA;
u32 byteB;
}can;

extern void can_init(void);
extern void can_tx(can v);

extern void delay_ms(unsigned int ms);
extern void EINT0_Handler(void) __irq;
extern void EINT1_Handler(void) __irq;
extern void EINT2_Handler(void) __irq;
extern void config_vic_for_eint(void);
extern void config_eint(void);

