#include<lpc21xx.h>
#include"header.h"
extern can v1,v2,v3;
extern u32 flag1,flag2,flag3;

void EINT0_Handler(void) __irq
{
	flag1^=1;
	if(flag1)
	v1.byteA=0x10;     //headlight no
	else
	v1.byteA=0x11;     //headlight off
	can_tx(v1);

	EXTINT=1;
	VICVectAddr=0;
}


void EINT1_Handler(void) __irq
{
	flag2^=1;
	if(flag2)
	v2.byteA=0x12;     //rightind no
	else
	v2.byteA=0x13;     //rightind off
	
	can_tx(v2);

	EXTINT=2;
	VICVectAddr=0;
}


void EINT2_Handler(void) __irq
{

	flag3^=1;

	if(flag3)
	v3.byteA=0x14;     //leftind no
	else
	v3.byteA=0x15;     //leftind off
	can_tx(v3);
		
	EXTINT=4;
	VICVectAddr=0;
}


void config_vic_for_eint(void)
{
	VICIntSelect=0;
	VICVectAddr0|=(unsigned int)EINT0_Handler;
    VICVectAddr1|=(unsigned int)EINT1_Handler;
	VICVectAddr2|=(unsigned int)EINT2_Handler;
	VICVectCntl0|=14|(1<<5);
	VICVectCntl1|=15|(1<<5);
	VICVectCntl2|=16|(1<<5);
	VICIntEnable=(1<<14)|(1<<15)|(1<<16);
}


void config_eint(void)
{
	PINSEL1|=1;
	PINSEL0|=(10<<28);
	EXTMODE=7;
	EXTPOLAR=0;
}



