#include<lpc21xx.h>
#include"header.h"

can v1,v2,v3;
u32 flag1=0,flag2=0,flag3=0;
u32 c1=0;
int main()
{
can_init();
config_vic_for_eint();
config_eint();

v1.id=0x201;
v1.dlc=8;
v1.rtr=0;	//data frame

v2.id=0x202;
v2.dlc=8;
v2.rtr=0;

v3.id=0x203;
v3.dlc=8;
v3.rtr=0;

while(1)
{
c1++;
}
}

